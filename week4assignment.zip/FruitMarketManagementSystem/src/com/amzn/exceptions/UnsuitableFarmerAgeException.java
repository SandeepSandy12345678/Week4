package com.amzn.exceptions;

public class UnsuitableFarmerAgeException extends Exception {
	
	public UnsuitableFarmerAgeException() {
		super();
	}	
	
	
}
