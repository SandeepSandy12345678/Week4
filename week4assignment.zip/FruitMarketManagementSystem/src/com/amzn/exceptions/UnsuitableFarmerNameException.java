package com.amzn.exceptions;

public class UnsuitableFarmerNameException extends Exception {

	public UnsuitableFarmerNameException() {
		super();
	}

	public UnsuitableFarmerNameException(String message) {
		super(message);
	}

	
}
