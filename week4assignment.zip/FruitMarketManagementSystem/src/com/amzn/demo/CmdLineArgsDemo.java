package com.amzn.demo;

public class CmdLineArgsDemo {

	// execute program on cmd line as
	// java com.amzn.demo.CmdLineArgsDemo 6
	public static void main(String[] args) {
		System.out.println(args[0]);

	}

}
