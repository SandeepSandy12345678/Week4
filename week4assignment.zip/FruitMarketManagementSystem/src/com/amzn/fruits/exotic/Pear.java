package com.amzn.fruits.exotic;

import com.amzn.fruits.Mango;

/*

// Multiple Inheritance is not possible in Java
public class Pear extends Mango, Apple{

}
*/

//Java only allows Single Inheritance
public class Pear extends Mango
{

}
