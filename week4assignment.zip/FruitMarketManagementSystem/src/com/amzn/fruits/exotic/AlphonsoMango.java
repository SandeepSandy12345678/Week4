package com.amzn.fruits.exotic;

import com.amzn.fruits.Mango;

public class AlphonsoMango extends Mango{
	

	public AlphonsoMango(){
		
	}
	
	AlphonsoMango(String name){
		
	}	
	

	
}
