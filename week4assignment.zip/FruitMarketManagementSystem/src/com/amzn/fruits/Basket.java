package com.amzn.fruits;

import java.util.ArrayList;

public class Basket {
	

public static void main(String[] args) {
	int count=0;
	ArrayList<Mango> m=new ArrayList();
Mango m1=new Mango("Mango","light yellow",70);
Mango m2=new Mango("Mango","medium yellow",75);
Mango m3=new Mango("Mango","dark yellow",80);
Mango m4=new Mango("Apple","Kashmir apple",120);
Mango m5=new Mango("Apple","Karnataka apple",110);
Mango m6=new Mango("Apple","Karnataka apple",110);

//we are just using Mango and placing there Apple because
//we can add in a single array list
if(count<4) {
	m.add(m5);
	count++;
}
	if(count<4) {
		m.add(m4);
		count++;
	}
	if(count<4) {
		m.add(m3);
		count++;
		}
	if(count<4) {
		m.add(m3);
		count++;
		}
	if(count<4) {
		m.add(m3);
		count++;
		}
	if(count<4) {
		m.add(m2);
		count++;
	}
	if(count<4) {
		m.add(m5);
		count++;
	}
	if(count<4) {
		m.add(m6);
	}
for(Mango l:m) {
	System.out.println(l);
}


}

}
