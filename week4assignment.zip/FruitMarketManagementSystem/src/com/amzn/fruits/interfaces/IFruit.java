package com.amzn.fruits.interfaces;

public interface IFruit {	
	public static final int count = 0;
	
	// abstract methods
	void cut();
	
	void makeJuice();

}
