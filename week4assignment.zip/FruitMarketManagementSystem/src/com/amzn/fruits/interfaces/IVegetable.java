package com.amzn.fruits.interfaces;

public interface IVegetable {
		
	public void washVeg();
	
	public void makeCurry();

}