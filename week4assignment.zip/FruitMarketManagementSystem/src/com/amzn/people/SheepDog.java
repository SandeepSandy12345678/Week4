package com.amzn.people;

 class SheepDog {

	void eat() {
		
		
	}

}

