package com.amzn.people;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import com.amzn.fruits.Basket;
import com.amzn.fruits.Mango;

public class Retailerv4 {
public static void main(String[] args) throws IOException {
	ArrayList<Mango> m=new ArrayList();
	try {
	    FileOutputStream fos = new FileOutputStream("output");
	    ObjectOutputStream oos = new ObjectOutputStream(fos);   
	    oos.writeObject(m);
	    oos.close(); 
	} catch(Exception ex) {
	    ex.printStackTrace();
	}
}
}
