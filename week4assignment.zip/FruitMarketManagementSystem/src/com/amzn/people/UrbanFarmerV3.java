package com.amzn.people;

import com.amzn.logistics.Basket;

public class UrbanFarmerV3 implements Runnable {

	private String farmerName;
	private short age;
	Basket fruitBasket;

	public UrbanFarmerV3(String name, short age, Basket fruitBasket) {
		this.farmerName = name;
		this.age = age;
		this.fruitBasket = fruitBasket;
	}

	public String getFarmerName() {
		return farmerName;
	}

	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}

	public short getAge() {
		return age;
	}

	public void setAge(short age) {
		this.age = age;
	}

	public void harvest() throws InterruptedException {
		for (int i = 0; i < 10; i++) {			
			
			System.out.printf("%s harvesting %s-th fruit.. \n", this.farmerName, i);
			fruitBasket.addFruit(i);
			
			Thread.sleep(1000);// 1ms
		}
	}

	@Override
	public void run() {
		// System.out.printf("%s printing from thread.. \n",this.farmerName);
		try {
			harvest();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
