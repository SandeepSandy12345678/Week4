package com.amzn.logistics;

@FunctionalInterface
public interface Transport{
	
	public void ride();
	
	
}