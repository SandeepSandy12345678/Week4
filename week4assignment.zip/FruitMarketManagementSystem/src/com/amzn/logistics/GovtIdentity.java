package com.amzn.logistics;

public interface GovtIdentity {

    public void Authenticate(long aadhaar_no);
}