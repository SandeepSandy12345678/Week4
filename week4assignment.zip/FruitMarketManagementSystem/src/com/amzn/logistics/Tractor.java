package com.amzn.logistics;

public class Tractor implements Transport{

	@Override
	public void ride() {
				System.out.println(" Tractor ride..");
	}
	
	public void aa() {
		
	}

}
