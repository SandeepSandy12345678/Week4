package com.fruit;
public class Apple implements Fruit {
	public Apple(String name,String color,int price) {
		System.out.println("name "+name+"color "+color+"price "+price);
	}
	@Override
	final public void cut() {
		System.out.println("cutting apple...");
	}

	@Override
	public void makeJuice() {

		System.out.println("making apple juice... ");
	}

}